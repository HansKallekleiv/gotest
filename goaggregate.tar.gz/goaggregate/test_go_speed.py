import ctypes

golibrary = ctypes.cdll.LoadLibrary("./goaggregate/golibrary.so")
import zipfile
from io import BytesIO
import json
import xtgeo
import base64
from sumo.wrapper import SumoClient
from fmu.sumo.explorer.objects import CaseCollection, Case, SurfaceCollection
import logging
from io import BytesIO


import asyncio
from tabulate import tabulate
import multiprocessing

LOGGER = logging.getLogger(__name__)
import requests


class CustomError(Exception):
    def __init__(self, message, status_code, payload=None):
        Exception.__init__(self)
        self.message = message
        if status_code is not None:
            self.status_code = status_code
        self.payload = payload

    def to_dict(self):
        rv = dict(self.payload or ())
        rv["message"] = self.message
        return rv


class InternalError(CustomError):
    def __init__(self, message, payload=None):
        super().__init__(message, 500, payload)


class Unauthorized(CustomError):
    def __init__(self, message, payload=None):
        super().__init__(message, 401, payload)


class Forbidden(CustomError):
    def __init__(self, message, payload=None):
        super().__init__(message, 403, payload)


class BadRequest(CustomError):
    def __init__(self, message, payload=None):
        super().__init__(message, 400, payload)


import time


class PerfTimer:
    def __init__(self) -> None:
        self._start_s = time.perf_counter()
        self._lap_s = self._start_s

    def elapsed_s(self) -> float:
        """Get the time elapsed since the start, in seconds"""
        return time.perf_counter() - self._start_s

    def elapsed_ms(self) -> int:
        """Get the time elapsed since the start, in milliseconds"""
        return int(1000 * self.elapsed_s())

    def lap_s(self) -> float:
        """Get elapsed time since last lap, in seconds"""
        time_now = time.perf_counter()
        elapsed = time_now - self._lap_s
        self._lap_s = time_now
        return elapsed

    def lap_ms(self) -> int:
        """Get elapsed time since last lap, in milliseconds"""
        return int(1000 * self.lap_s())


def get_base_uri_and_auth_token_for_case(case_id, env, token):
    temp_uri = f"{get_base_uri(env)}/objects('{case_id}')/authtoken"

    body, _ = get_with_token(temp_uri, token)

    base_uri = body["baseuri"].removesuffix("/")
    auth_token = body["auth"]

    return base_uri, auth_token


def get_base_uri(env):
    return f"https://main-sumo-{env}.radix.equinor.com/api/v1"


def get_uri(env, path):
    return f"{get_base_uri(env)}{path}"


def get_with_token(url, token):
    try:
        res = requests.get(url, headers={"Authorization": f"Bearer {token}"})
    except requests.exceptions.RequestException as err:
        raise InternalError(
            f"RequestException: An error occured while handling request: {err}",
            payload={"request_url": url},
        )
    return res.json(), res.status_code


def go_get_surface_blobs(
    sumo_token: str, case_uuid: str, object_ids: list[str]
) -> list[xtgeo.RegularSurface]:
    timer = PerfTimer()
    GetZippedBlobs = golibrary.GetZippedBlobs
    GetZippedBlobs.restype = ctypes.c_void_p
    base_uri, auth_token = get_base_uri_and_auth_token_for_case(
        case_uuid,
        "prod",
        sumo_token,
    )
    new_request = {
        "base_uri": base_uri,
        "auth_token": auth_token,
        "object_ids": object_ids,
        "bearer_token": sumo_token,
        "env": "prod",
    }
    elapsed_init = timer.lap_ms()
    res = GetZippedBlobs(json.dumps(new_request).encode("utf-8"))

    elapsed_get = timer.lap_ms()
    res_string = ctypes.string_at(res).decode("ascii")
    size_bytes = len(res_string)
    size_mb = size_bytes / (1024 * 1024)
    data_map_b64 = json.loads(res_string)
    speed_mbps = (size_bytes * 8) / (elapsed_get * 1024)
    elapsed_decode = timer.lap_ms()
    log = {
        "Method": "GO",
        "Download(s)": f"{elapsed_get/1000:.2f}",
        "Size(MB)": f"{size_mb:.2f}",
        "Speed(Mbit)": int(speed_mbps),
        "Count": len(object_ids),
    }

    return data_map_b64, log


async def get_blob_async(client, object_id) -> BytesIO:
    """Object blob"""
    res = await client.get_async(f"/objects('{object_id}')/blob")
    # blob = BytesIO(res.content)
    return res.content


def async_result_to_xtgeo_surface(blob):
    return xtgeo.surface_from_file(BytesIO(blob), fformat="irap_binary")


def multiprocess_async_results_to_xtgeo_surfaces(blobs):
    timer = PerfTimer()
    with multiprocessing.Pool(8) as pool:
        result = pool.map(async_result_to_xtgeo_surface, blobs)
    elapsed_xtgeo = timer.lap_ms()
    log = {
        "To xtgeo(s)": f"{elapsed_xtgeo/1000:.2f}",
    }
    return result, log


def go_result_to_xtgeo_surface(blob):
    bytestr = base64.b64decode(blob)
    return xtgeo.surface_from_file(BytesIO(bytestr), fformat="irap_binary")


def multiprocess_go_results_to_xtgeo_surfaces(blobs):
    timer = PerfTimer()

    with multiprocessing.Pool(8) as pool:
        result = pool.map(go_result_to_xtgeo_surface, blobs)
    elapsed_xtgeo = timer.lap_ms()
    log = {
        "To xtgeo(s)": f"{elapsed_xtgeo/1000:.2f}",
    }
    return result, log


async def async_get_surface_blobs(client, object_ids) -> list[BytesIO]:
    """Object blobs"""
    timer = PerfTimer()
    result = await asyncio.gather(
        *[get_blob_async(client, object_id) for object_id in object_ids]
    )
    elapsed_get = timer.lap_ms()
    size_bytes = sum([len(blob) for blob in result])
    size_mb = size_bytes / (1024 * 1024)
    speed_mbps = (size_bytes * 8) / (elapsed_get * 1024)
    log = {
        "Method": "ASYNC",
        "Download(s)": f"{elapsed_get/1000:.2f}",
        "Size(MB)": f"{size_mb:.2f}",
        "Speed(Mbit)": int(speed_mbps),
        "Count": len(object_ids),
    }

    return result, log


def get_uuids(case_uuid, ensemble_name, snames, sattr, bearer_token, realizations=None):
    sumo_client = SumoClient(env="prod", token=bearer_token, interactive=False)
    case_collection = CaseCollection(sumo_client).filter(uuid=case_uuid)
    case = case_collection[0]
    surface_collection = case.surfaces.filter(
        iteration=ensemble_name,
        name=snames,
        tagname=sattr,
        realization=realizations,
    )
    return [surf.uuid for surf in surface_collection]


case_uuid = "add9d634-f936-40f8-a758-0ed5b0410377"
sumo_client = SumoClient(env="prod", interactive=True)
token = sumo_client.authenticate()
uuids = get_uuids(
    case_uuid,
    "pred",
    ["Eiriksson Fm. 1 JS Top"],
    "depth_structural_model",
    token,
)

go_res, go_log = go_get_surface_blobs(token, case_uuid, uuids)
go_xtgeos, go_xtgeo_log = multiprocess_go_results_to_xtgeo_surfaces(go_res.values())
go_log.update(go_xtgeo_log)
async_res, async_log = asyncio.run(async_get_surface_blobs(sumo_client, uuids))
async_xtgeos, async_xtgeo_log = multiprocess_async_results_to_xtgeo_surfaces(async_res)
async_log.update(async_xtgeo_log)
headers = go_log.keys()

rows = [go_log.values(), async_log.values()]

print(tabulate(rows, headers=headers))
