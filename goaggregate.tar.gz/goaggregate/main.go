package main

import "C"
import (
	"encoding/json"
	"fmt"
	"time"
	"C"
	goaggregate "goaggregate/utils"
)



//export GetZippedBlobs
func GetZippedBlobs(request *C.char) *C.char {
	requestString := C.GoString(request)
	aggReq := goaggregate.BlobsRequest{}
	err := json.Unmarshal([]byte(requestString), &aggReq)
	if err != nil {
		fmt.Println(err)
	}

	startTime := time.Now()

	dataMap, errArray := goaggregate.GetBlobsRaw(aggReq.ObjectIDs, aggReq.AuthToken, aggReq.BaseUri)

	endTime := time.Now()

	duration := endTime.Sub(startTime)

	if len(errArray) > 0 {
	
	}


	var totalSize int
	for _, blob := range dataMap {
		totalSize += len(blob)
	}

	const bytesPerMB = 1048576
	downloadSpeed := float64(totalSize) / duration.Seconds() / bytesPerMB

	fmt.Printf("Time spent in GetBlobsRaw: %v\n", duration)
	fmt.Printf("Download speed: %f bytes/sec\n", downloadSpeed)

	jsonData, err := json.Marshal(dataMap)
	if err != nil {
	
	}

	return C.CString(string(jsonData))
}

func main() {

}

